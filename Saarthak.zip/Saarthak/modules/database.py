import os
import logging
from datetime import datetime
from typing import Dict, List, Any, Optional
from sqlalchemy import create_engine, Column, Integer, String, Float, Boolean, DateTime, Text, JSON
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker, Session
from sqlalchemy.exc import SQLAlchemyError

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

Base = declarative_base()

class Incident(Base):
    """Database model for garbage detection incidents."""
    __tablename__ = 'incidents'
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    incident_id = Column(String(50), unique=True, nullable=False)
    timestamp = Column(DateTime, default=datetime.utcnow, nullable=False)
    location = Column(String(255), nullable=False)
    video_file = Column(String(255), nullable=False)
    violations_count = Column(Integer, default=0)
    authority_email = Column(String(255))
    authority_notified = Column(Boolean, default=False)
    status = Column(String(50), default='pending')  # pending, resolved, escalated
    severity = Column(String(20), default='low')  # low, medium, high
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

class Detection(Base):
    """Database model for individual garbage detections."""
    __tablename__ = 'detections'
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    incident_id = Column(String(50), nullable=False)
    timestamp = Column(Float, nullable=False)  # Video timestamp in seconds
    confidence = Column(Float, nullable=False)
    detected = Column(Boolean, default=False)
    description = Column(Text)
    violation_type = Column(String(100))
    location_description = Column(Text)
    frame_data = Column(Text)  # Base64 encoded frame (optional)
    created_at = Column(DateTime, default=datetime.utcnow)

class AnalysisSession(Base):
    """Database model for video analysis sessions."""
    __tablename__ = 'analysis_sessions'
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    session_id = Column(String(50), unique=True, nullable=False)
    video_file = Column(String(255), nullable=False)
    location = Column(String(255), nullable=False)
    analysis_time = Column(DateTime, default=datetime.utcnow)
    total_frames = Column(Integer, default=0)
    violations_found = Column(Integer, default=0)
    confidence_threshold = Column(Float, default=0.7)
    status = Column(String(50), default='completed')  # processing, completed, failed
    analysis_metadata = Column(JSON)  # Store additional video/analysis metadata
    created_at = Column(DateTime, default=datetime.utcnow)

class DatabaseManager:
    """Handle database operations for garbage detection system."""
    
    def __init__(self):
        self.database_url = os.getenv('DATABASE_URL')
        if not self.database_url:
            logger.error("DATABASE_URL environment variable not found")
            raise ValueError("DATABASE_URL is required")
        
        try:
            self.engine = create_engine(self.database_url, echo=False)
            self.SessionLocal = sessionmaker(bind=self.engine)
            logger.info("Database connection established successfully")
        except Exception as e:
            logger.error(f"Failed to connect to database: {e}")
            raise
    
    def create_tables(self):
        """Create all database tables."""
        try:
            Base.metadata.create_all(bind=self.engine)
            logger.info("Database tables created successfully")
        except Exception as e:
            logger.error(f"Failed to create tables: {e}")
            raise
    
    def get_session(self) -> Session:
        """Get a database session."""
        return self.SessionLocal()
    
    def save_incident(self, incident_data: Dict[str, Any]) -> str:
        """Save an incident to the database."""
        session = self.get_session()
        try:
            # Generate unique incident ID if not provided
            if 'incident_id' not in incident_data:
                incident_data['incident_id'] = f"INC_{datetime.now().strftime('%Y%m%d_%H%M%S_%f')}"
            
            incident = Incident(**incident_data)
            session.add(incident)
            session.commit()
            
            logger.info(f"Incident saved: {incident.incident_id}")
            return incident.incident_id
            
        except SQLAlchemyError as e:
            session.rollback()
            logger.error(f"Failed to save incident: {e}")
            raise
        finally:
            session.close()
    
    def save_detections(self, detections: List[Dict[str, Any]]) -> bool:
        """Save multiple detection results to the database."""
        session = self.get_session()
        try:
            detection_objects = [Detection(**detection) for detection in detections]
            session.add_all(detection_objects)
            session.commit()
            
            logger.info(f"Saved {len(detections)} detections")
            return True
            
        except SQLAlchemyError as e:
            session.rollback()
            logger.error(f"Failed to save detections: {e}")
            return False
        finally:
            session.close()
    
    def save_analysis_session(self, session_data: Dict[str, Any]) -> str:
        """Save an analysis session to the database."""
        session = self.get_session()
        try:
            # Generate unique session ID if not provided
            if 'session_id' not in session_data:
                session_data['session_id'] = f"SES_{datetime.now().strftime('%Y%m%d_%H%M%S_%f')}"
            
            analysis_session = AnalysisSession(**session_data)
            session.add(analysis_session)
            session.commit()
            
            logger.info(f"Analysis session saved: {analysis_session.session_id}")
            return analysis_session.session_id
            
        except SQLAlchemyError as e:
            session.rollback()
            logger.error(f"Failed to save analysis session: {e}")
            raise
        finally:
            session.close()
    
    def get_incidents(self, limit: int = 100, status: str = None) -> List[Dict[str, Any]]:
        """Retrieve incidents from the database."""
        session = self.get_session()
        try:
            query = session.query(Incident)
            
            if status:
                query = query.filter(Incident.status == status)
            
            incidents = query.order_by(Incident.created_at.desc()).limit(limit).all()
            
            # Convert to dictionary format
            result = []
            for incident in incidents:
                result.append({
                    'id': incident.id,
                    'incident_id': incident.incident_id,
                    'timestamp': incident.timestamp,
                    'location': incident.location,
                    'video_file': incident.video_file,
                    'violations_count': incident.violations_count,
                    'authority_email': incident.authority_email,
                    'authority_notified': incident.authority_notified,
                    'status': incident.status,
                    'severity': incident.severity,
                    'created_at': incident.created_at,
                    'updated_at': incident.updated_at
                })
            
            return result
            
        except SQLAlchemyError as e:
            logger.error(f"Failed to retrieve incidents: {e}")
            return []
        finally:
            session.close()
    
    def get_detections_by_incident(self, incident_id: str) -> List[Dict[str, Any]]:
        """Get all detections for a specific incident."""
        session = self.get_session()
        try:
            detections = session.query(Detection).filter(
                Detection.incident_id == incident_id
            ).order_by(Detection.timestamp.asc()).all()
            
            result = []
            for detection in detections:
                result.append({
                    'id': detection.id,
                    'incident_id': detection.incident_id,
                    'timestamp': detection.timestamp,
                    'confidence': detection.confidence,
                    'detected': detection.detected,
                    'description': detection.description,
                    'violation_type': detection.violation_type,
                    'location_description': detection.location_description,
                    'created_at': detection.created_at
                })
            
            return result
            
        except SQLAlchemyError as e:
            logger.error(f"Failed to retrieve detections: {e}")
            return []
        finally:
            session.close()
    
    def update_incident_status(self, incident_id: str, status: str, authority_notified: Optional[bool] = None) -> bool:
        """Update incident status and notification status."""
        session = self.get_session()
        try:
            incident = session.query(Incident).filter(
                Incident.incident_id == incident_id
            ).first()
            
            if incident:
                # Update incident attributes
                session.query(Incident).filter(
                    Incident.incident_id == incident_id
                ).update({
                    'status': status,
                    'updated_at': datetime.utcnow(),
                    'authority_notified': authority_notified if authority_notified is not None else incident.authority_notified
                })
                
                session.commit()
                logger.info(f"Updated incident {incident_id}: status={status}")
                return True
            else:
                logger.warning(f"Incident not found: {incident_id}")
                return False
                
        except SQLAlchemyError as e:
            session.rollback()
            logger.error(f"Failed to update incident: {e}")
            return False
        finally:
            session.close()
    
    def get_statistics(self) -> Dict[str, Any]:
        """Get system statistics."""
        session = self.get_session()
        try:
            # Count incidents by status
            total_incidents = session.query(Incident).count()
            pending_incidents = session.query(Incident).filter(Incident.status == 'pending').count()
            resolved_incidents = session.query(Incident).filter(Incident.status == 'resolved').count()
            
            # Get top locations
            from sqlalchemy import text, func
            location_query = session.query(
                Incident.location,
                func.count(Incident.location).label('count')
            ).group_by(Incident.location).order_by(func.count(Incident.location).desc()).limit(5).all()
            
            # Count total violations
            total_violations = session.query(Detection).filter(Detection.detected == True).count()
            
            return {
                'total_incidents': total_incidents,
                'pending_incidents': pending_incidents,
                'resolved_incidents': resolved_incidents,
                'total_violations': total_violations,
                'top_locations': [(loc[0], loc[1]) for loc in location_query] if location_query else []
            }
            
        except SQLAlchemyError as e:
            logger.error(f"Failed to get statistics: {e}")
            return {}
        finally:
            session.close()