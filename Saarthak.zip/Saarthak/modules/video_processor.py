import cv2
import numpy as np
from typing import List, Tuple, Dict

class VideoProcessor:
    """Handle video processing operations for garbage detection."""
    
    def __init__(self):
        pass
    
    def get_video_info(self, video_path: str) -> Dict:
        """Extract basic information from video file."""
        cap = cv2.VideoCapture(video_path)
        
        if not cap.isOpened():
            raise ValueError("Could not open video file")
        
        fps = cap.get(cv2.CAP_PROP_FPS)
        frame_count = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
        width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
        height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
        duration = frame_count / fps if fps > 0 else 0
        
        cap.release()
        
        return {
            'fps': fps,
            'frame_count': frame_count,
            'width': width,
            'height': height,
            'duration': duration
        }
    
    def extract_frames(self, video_path: str, interval_seconds: int = 5) -> List[Tuple[float, np.ndarray]]:
        """Extract frames from video at specified intervals."""
        cap = cv2.VideoCapture(video_path)
        
        if not cap.isOpened():
            raise ValueError("Could not open video file")
        
        fps = cap.get(cv2.CAP_PROP_FPS)
        frame_interval = int(fps * interval_seconds)
        
        frames = []
        frame_number = 0
        
        while True:
            ret, frame = cap.read()
            if not ret:
                break
            
            if frame_number % frame_interval == 0:
                timestamp = frame_number / fps
                # Convert BGR to RGB for consistency with PIL/OpenAI
                frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
                frames.append((timestamp, frame_rgb))
            
            frame_number += 1
        
        cap.release()
        return frames
    
    def resize_frame(self, frame: np.ndarray, max_size: int = 1024) -> np.ndarray:
        """Resize frame while maintaining aspect ratio."""
        height, width = frame.shape[:2]
        
        if max(height, width) <= max_size:
            return frame
        
        if width > height:
            new_width = max_size
            new_height = int(height * (max_size / width))
        else:
            new_height = max_size
            new_width = int(width * (max_size / height))
        
        return cv2.resize(frame, (new_width, new_height), interpolation=cv2.INTER_AREA)
    
    def frame_to_base64(self, frame: np.ndarray) -> str:
        """Convert frame to base64 string for API transmission."""
        import base64
        from PIL import Image
        import io
        
        # Convert numpy array to PIL Image
        pil_image = Image.fromarray(frame)
        
        # Convert to base64
        buffer = io.BytesIO()
        pil_image.save(buffer, format='JPEG', quality=85)
        img_str = base64.b64encode(buffer.getvalue()).decode()
        
        return img_str
