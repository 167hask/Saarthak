import os
import sys
import smtplib
import ssl
from datetime import datetime
from typing import Dict, List, Any
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart

class EmailNotifier:
    """Handle email notifications to municipal authorities using Gmail SMTP."""
    
    def __init__(self):
        self.smtp_server = "smtp.gmail.com"
        self.smtp_port = 587
        self.sender_email = os.getenv('SENDER_EMAIL', '')
        self.sender_password = os.getenv('SENDER_PASSWORD', '')
        
        # Validate both email and password are provided
        if not self.sender_email or not self.sender_password:
            print("Warning: Email configuration incomplete")
            print("To use Gmail SMTP, you need to:")
            print("1. Enable 2-factor authentication on your Gmail account")
            print("2. Generate an App Password for this application")
            print("3. Set BOTH environment variables:")
            print("   - SENDER_EMAIL: your-email@gmail.com")
            print("   - SENDER_PASSWORD: your-app-password")
    
    def send_violation_report(self, authority_email: str, report_data: Dict[str, Any]) -> bool:
        """Send violation report to municipal authorities."""
        if not self.sender_email or not self.sender_password:
            print("Email not configured - both SENDER_EMAIL and SENDER_PASSWORD are required")
            return False
        
        try:
            # Generate email content
            subject = f"🚨 Garbage Violation Report - {report_data['location']}"
            
            html_content = self._generate_html_report(report_data)
            text_content = self._generate_text_report(report_data)
            
            # Create email message
            message = MIMEMultipart("alternative")
            message["Subject"] = subject
            message["From"] = self.sender_email
            message["To"] = authority_email
            
            # Add both text and HTML parts
            text_part = MIMEText(text_content, "plain")
            html_part = MIMEText(html_content, "html")
            
            message.attach(text_part)
            message.attach(html_part)
            
            # Create secure connection and send email
            context = ssl.create_default_context()
            
            with smtplib.SMTP(self.smtp_server, self.smtp_port) as server:
                server.starttls(context=context)
                server.login(self.sender_email, self.sender_password)
                server.send_message(message)
            
            print(f"Violation report sent successfully to {authority_email}")
            return True
            
        except Exception as e:
            print(f"Email sending error: {e}")
            return False
    
    def _generate_html_report(self, report_data: Dict[str, Any]) -> str:
        """Generate HTML email report."""
        violations = report_data['violations']
        
        html = f"""
        <!DOCTYPE html>
        <html>
        <head>
            <style>
                body {{ font-family: Arial, sans-serif; margin: 20px; }}
                .header {{ background-color: #d32f2f; color: white; padding: 20px; text-align: center; }}
                .content {{ padding: 20px; }}
                .violation {{ border: 1px solid #ddd; margin: 20px 0; padding: 15px; border-radius: 5px; }}
                .violation-header {{ background-color: #ffebee; padding: 10px; margin-bottom: 10px; font-weight: bold; }}
                .details {{ margin: 10px 0; }}
                .footer {{ text-align: center; margin-top: 30px; color: #666; }}
            </style>
        </head>
        <body>
            <div class="header">
                <h1>🚨 GARBAGE VIOLATION ALERT</h1>
                <p>Automated Detection System Report</p>
            </div>
            
            <div class="content">
                <h2>Incident Summary</h2>
                <div class="details">
                    <strong>Location:</strong> {report_data['location']}<br>
                    <strong>Detection Time:</strong> {report_data['detection_time']}<br>
                    <strong>Total Violations:</strong> {len(violations)}<br>
                    <strong>Video Source:</strong> {report_data['video_file']}<br>
                </div>
                
                <h2>Violation Details</h2>
        """
        
        for i, violation in enumerate(violations, 1):
            html += f"""
                <div class="violation">
                    <div class="violation-header">Violation #{i}</div>
                    <div class="details">
                        <strong>Timestamp:</strong> {violation['timestamp']:.2f} seconds<br>
                        <strong>Confidence Score:</strong> {violation['confidence']:.1%}<br>
                        <strong>Violation Type:</strong> {violation.get('violation_type', 'Illegal dumping')}<br>
                        <strong>Description:</strong> {violation['description']}<br>
                        <strong>Location in Frame:</strong> {violation.get('location_description', 'See attached frame')}
                    </div>
                </div>
            """
        
        html += f"""
            </div>
            
            <div class="footer">
                <p>This report was generated automatically by the AI-Powered Garbage Detection System.</p>
                <p>Report generated on: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}</p>
            </div>
        </body>
        </html>
        """
        
        return html
    
    def _generate_text_report(self, report_data: Dict[str, Any]) -> str:
        """Generate plain text email report."""
        violations = report_data['violations']
        
        text = f"""
GARBAGE VIOLATION ALERT
========================

INCIDENT SUMMARY
Location: {report_data['location']}
Detection Time: {report_data['detection_time']}
Total Violations: {len(violations)}
Video Source: {report_data['video_file']}

VIOLATION DETAILS
=================
"""
        
        for i, violation in enumerate(violations, 1):
            text += f"""
Violation #{i}:
- Timestamp: {violation['timestamp']:.2f} seconds
- Confidence Score: {violation['confidence']:.1%}
- Violation Type: {violation.get('violation_type', 'Illegal dumping')}
- Description: {violation['description']}
- Location in Frame: {violation.get('location_description', 'See attached frame')}

"""
        
        text += f"""
---
This report was generated automatically by the AI-Powered Garbage Detection System.
Report generated on: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
        """
        
        return text
    
    def send_test_email(self, to_email: str) -> bool:
        """Send a test email to verify configuration."""
        if not self.sender_email or not self.sender_password:
            print("Email not configured - both SENDER_EMAIL and SENDER_PASSWORD are required")
            return False
        
        try:
            # Create test email message
            message = MIMEMultipart()
            message["Subject"] = "Test Email - Garbage Detection System"
            message["From"] = self.sender_email
            message["To"] = to_email
            
            # Add test content
            test_content = """
            <p>This is a test email from the Garbage Detection System.</p>
            <p>If you receive this, the email configuration is working correctly.</p>
            <p>The system is now ready to send violation reports to municipal authorities.</p>
            """
            
            html_part = MIMEText(test_content, "html")
            message.attach(html_part)
            
            # Send test email
            context = ssl.create_default_context()
            
            with smtplib.SMTP(self.smtp_server, self.smtp_port) as server:
                server.starttls(context=context)
                server.login(self.sender_email, self.sender_password)
                server.send_message(message)
            
            print(f"Test email sent successfully to {to_email}")
            return True
            
        except Exception as e:
            print(f"Test email failed: {e}")
            return False
