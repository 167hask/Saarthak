import json
import os
import base64
import numpy as np
from typing import Dict, Any
from openai import OpenAI

class AIAnalyzer:
    """AI-powered garbage detection using OpenAI's vision capabilities."""
    
    def __init__(self):
        # the newest OpenAI model is "gpt-5" which was released August 7, 2025.
        # do not change this unless explicitly requested by the user
        self.api_key = os.getenv("OPENAI_API_KEY")
        if self.api_key:
            self.openai_client = OpenAI(api_key=self.api_key)
        else:
            self.openai_client = None
            print("Warning: OPENAI_API_KEY not found. AI analysis will not work until configured.")
        self.model = "gpt-5"
    
    def detect_garbage(self, frame: np.ndarray) -> Dict[str, Any]:
        """Detect garbage in a video frame using OpenAI vision API."""
        if not self.openai_client:
            return {
                "detected": False,
                "confidence": 0.0,
                "description": "OpenAI API not configured. Please set OPENAI_API_KEY environment variable.",
                "violation_type": "Configuration Error",
                "location_description": "API configuration required"
            }
            
        try:
            # Convert frame to base64
            frame_base64 = self._frame_to_base64(frame)
            
            # Prepare the prompt for garbage detection
            prompt = """Analyze this image for illegal garbage dumping or littering. 
            Look for:
            - Garbage bags, trash, or litter on streets, sidewalks, or inappropriate locations
            - People in the act of dumping garbage illegally
            - Accumulation of waste in public spaces
            - Any form of improper waste disposal
            
            Respond with JSON in this exact format:
            {
                "detected": boolean,
                "confidence": number between 0 and 1,
                "description": "detailed description of what was detected",
                "violation_type": "type of violation if any",
                "location_description": "description of where the garbage is located in the image"
            }
            
            Be very specific about what you see and provide high confidence only for clear violations."""
            
            response = self.openai_client.chat.completions.create(
                model=self.model,
                messages=[
                    {
                        "role": "user",
                        "content": [
                            {
                                "type": "text",
                                "text": prompt
                            },
                            {
                                "type": "image_url",
                                "image_url": {
                                    "url": f"data:image/jpeg;base64,{frame_base64}"
                                }
                            }
                        ]
                    }
                ],
                response_format={"type": "json_object"},
                max_completion_tokens=1000
            )
            
            # Parse the response
            content = response.choices[0].message.content or "{}"
            result = json.loads(content)
            
            # Ensure all required fields are present with defaults
            return {
                "detected": result.get("detected", False),
                "confidence": max(0.0, min(1.0, result.get("confidence", 0.0))),
                "description": result.get("description", "No description available"),
                "violation_type": result.get("violation_type", "Unknown"),
                "location_description": result.get("location_description", "Location unclear")
            }
            
        except Exception as e:
            # Return error state
            return {
                "detected": False,
                "confidence": 0.0,
                "description": f"Analysis failed: {str(e)}",
                "violation_type": "Error",
                "location_description": "Analysis error"
            }
    
    def _frame_to_base64(self, frame: np.ndarray) -> str:
        """Convert numpy frame to base64 string."""
        import cv2
        from PIL import Image
        import io
        
        # Resize frame if too large (max 1024px on longest side)
        height, width = frame.shape[:2]
        max_size = 1024
        
        if max(height, width) > max_size:
            if width > height:
                new_width = max_size
                new_height = int(height * (max_size / width))
            else:
                new_height = max_size
                new_width = int(width * (max_size / height))
            
            frame = cv2.resize(frame, (new_width, new_height), interpolation=cv2.INTER_AREA)
        
        # Convert RGB to PIL Image and then to base64
        pil_image = Image.fromarray(frame)
        buffer = io.BytesIO()
        pil_image.save(buffer, format='JPEG', quality=85)
        img_str = base64.b64encode(buffer.getvalue()).decode()
        
        return img_str
    
    def batch_analyze_frames(self, frames: list, progress_callback=None) -> list:
        """Analyze multiple frames in batch."""
        results = []
        
        for i, (timestamp, frame) in enumerate(frames):
            if progress_callback:
                progress_callback(i, len(frames))
            
            detection_result = self.detect_garbage(frame)
            detection_result['timestamp'] = timestamp
            results.append(detection_result)
        
        return results
