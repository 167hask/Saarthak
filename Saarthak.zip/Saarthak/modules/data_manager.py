import pandas as pd
from datetime import datetime
from typing import Dict, List, Any, Optional
import json
import logging
from .database import DatabaseManager

# Configure logging
logger = logging.getLogger(__name__)

class DataManager:
    """Handle data management for detection results and incident reporting."""
    
    def __init__(self):
        try:
            self.db = DatabaseManager()
            self.db.create_tables()
            self.use_database = True
            logger.info("Database initialized successfully")
        except Exception as e:
            logger.warning(f"Database not available: {e}. Falling back to in-memory storage.")
            self.db = None
            self.use_database = False
    
    def save_incident_to_database(self, violations: List[Dict], video_file: str, location: str, authority_email: str) -> Optional[str]:
        """Save incident and detections to database."""
        if not self.use_database:
            logger.warning("Database not available, cannot save incident")
            return None
        
        try:
            # Create incident record
            incident_data = {
                'location': location,
                'video_file': video_file,
                'violations_count': len(violations),
                'authority_email': authority_email,
                'authority_notified': False,
                'severity': self._calculate_severity(violations)
            }
            
            incident_id = self.db.save_incident(incident_data)
            
            # Save detection results
            detection_records = []
            for violation in violations:
                detection_record = {
                    'incident_id': incident_id,
                    'timestamp': violation.get('timestamp', 0),
                    'confidence': violation.get('confidence', 0),
                    'detected': violation.get('detected', True),
                    'description': violation.get('description', ''),
                    'violation_type': violation.get('violation_type', 'Unknown'),
                    'location_description': violation.get('location_description', '')
                }
                detection_records.append(detection_record)
            
            if detection_records:
                self.db.save_detections(detection_records)
            
            logger.info(f"Saved incident {incident_id} with {len(violations)} violations")
            return incident_id
            
        except Exception as e:
            logger.error(f"Failed to save incident to database: {e}")
            return None
    
    def get_incidents_from_database(self, limit: int = 100) -> List[Dict[str, Any]]:
        """Retrieve incidents from database."""
        if not self.use_database:
            return []
        
        try:
            return self.db.get_incidents(limit)
        except Exception as e:
            logger.error(f"Failed to retrieve incidents: {e}")
            return []
    
    def update_incident_notification_status(self, incident_id: str, notified: bool = True) -> bool:
        """Update incident notification status in database."""
        if not self.use_database:
            return False
        
        try:
            return self.db.update_incident_status(incident_id, 'pending', authority_notified=notified)
        except Exception as e:
            logger.error(f"Failed to update incident notification status: {e}")
            return False
    
    def generate_violation_report(self, violations: List[Dict], video_file: str, location: str) -> Dict[str, Any]:
        """Generate a comprehensive violation report."""
        return {
            'report_id': f"GDR_{datetime.now().strftime('%Y%m%d_%H%M%S')}",
            'detection_time': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            'location': location,
            'video_file': video_file,
            'violations': violations,
            'total_violations': len(violations),
            'highest_confidence': max([v['confidence'] for v in violations]) if violations else 0,
            'average_confidence': sum([v['confidence'] for v in violations]) / len(violations) if violations else 0,
        }
    
    def create_incident_summary(self, violations: List[Dict], location: str, video_file: str) -> Dict[str, Any]:
        """Create a summary of the incident for logging."""
        if not violations:
            return {}
        
        return {
            'incident_id': f"INC_{datetime.now().strftime('%Y%m%d_%H%M%S')}",
            'timestamp': datetime.now(),
            'location': location,
            'video_source': video_file,
            'violation_count': len(violations),
            'confidence_scores': [v['confidence'] for v in violations],
            'violation_types': list(set([v.get('violation_type', 'Unknown') for v in violations])),
            'time_range': {
                'start': min([v['timestamp'] for v in violations]),
                'end': max([v['timestamp'] for v in violations])
            },
            'severity': self._calculate_severity(violations)
        }
    
    def _calculate_severity(self, violations: List[Dict]) -> str:
        """Calculate incident severity based on violations."""
        if not violations:
            return "None"
        
        avg_confidence = sum([v['confidence'] for v in violations]) / len(violations)
        violation_count = len(violations)
        
        if avg_confidence > 0.9 or violation_count > 5:
            return "High"
        elif avg_confidence > 0.7 or violation_count > 2:
            return "Medium"
        else:
            return "Low"
    
    def export_detection_results(self, detection_results: List[Dict], format: str = 'csv') -> str:
        """Export detection results to specified format."""
        if format.lower() == 'csv':
            df = pd.DataFrame(detection_results)
            return df.to_csv(index=False)
        elif format.lower() == 'json':
            return json.dumps(detection_results, indent=2, default=str)
        else:
            raise ValueError(f"Unsupported export format: {format}")
    
    def generate_statistics(self, incidents: List[Dict] = None) -> Dict[str, Any]:
        """Generate statistics from incident data."""
        
        # Try to get statistics from database first
        if self.use_database:
            try:
                db_stats = self.db.get_statistics()
                if db_stats:
                    return db_stats
            except Exception as e:
                logger.error(f"Failed to get database statistics: {e}")
        
        # Fallback to provided incidents or empty data
        if not incidents:
            return {
                'total_incidents': 0,
                'total_violations': 0,
                'average_violations_per_incident': 0,
                'locations': [],
                'monthly_trends': {},
                'severity_distribution': {}
            }
        
        # Basic statistics
        total_incidents = len(incidents)
        total_violations = sum([inc.get('violations_count', 0) for inc in incidents])
        avg_violations = total_violations / total_incidents if total_incidents > 0 else 0
        
        # Location analysis
        locations = {}
        for incident in incidents:
            loc = incident.get('location', 'Unknown')
            locations[loc] = locations.get(loc, 0) + 1
        
        # Monthly trends
        monthly_trends = {}
        for incident in incidents:
            if 'timestamp' in incident:
                month_key = incident['timestamp'].strftime('%Y-%m') if hasattr(incident['timestamp'], 'strftime') else 'Unknown'
                monthly_trends[month_key] = monthly_trends.get(month_key, 0) + 1
        
        return {
            'total_incidents': total_incidents,
            'total_violations': total_violations,
            'average_violations_per_incident': round(avg_violations, 2),
            'top_locations': sorted(locations.items(), key=lambda x: x[1], reverse=True)[:5],
            'monthly_trends': monthly_trends,
            'most_recent_incident': max([inc.get('timestamp', datetime.min) for inc in incidents]) if incidents else None
        }
    
    def filter_violations_by_confidence(self, violations: List[Dict], min_confidence: float) -> List[Dict]:
        """Filter violations by minimum confidence threshold."""
        return [v for v in violations if v.get('confidence', 0) >= min_confidence]
    
    def get_violation_timeline(self, violations: List[Dict]) -> List[Dict]:
        """Create a timeline of violations for visualization."""
        timeline = []
        for violation in violations:
            timeline.append({
                'timestamp': violation.get('timestamp', 0),
                'confidence': violation.get('confidence', 0),
                'type': violation.get('violation_type', 'Unknown'),
                'description': violation.get('description', '')[:100] + "..." if len(violation.get('description', '')) > 100 else violation.get('description', '')
            })
        
        return sorted(timeline, key=lambda x: x['timestamp'])
