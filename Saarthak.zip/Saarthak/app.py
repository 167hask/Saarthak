import streamlit as st
import pandas as pd
import cv2
import numpy as np
from datetime import datetime
import base64
import tempfile
import os
from modules.video_processor import VideoProcessor
from modules.ai_analyzer import AIAnalyzer
from modules.email_notifier import EmailNotifier
from modules.data_manager import DataManager
from utils.helpers import format_confidence_score, format_timestamp

# Initialize session state
if 'incidents' not in st.session_state:
    st.session_state.incidents = []
if 'current_analysis' not in st.session_state:
    st.session_state.current_analysis = None

# Initialize modules
@st.cache_resource
def initialize_modules():
    return {
        'video_processor': VideoProcessor(),
        'ai_analyzer': AIAnalyzer(),
        'email_notifier': EmailNotifier(),
        'data_manager': DataManager()
    }

modules = initialize_modules()

# Page configuration
st.set_page_config(
    page_title="Garbage Detection System",
    page_icon="🗑️",
    layout="wide"
)

# Title and description
st.title("🗑️ AI-Powered Garbage Detection System")
st.markdown("Upload CCTV footage to detect illegal garbage dumping and generate violation reports for municipal authorities.")

# Sidebar for configuration
st.sidebar.header("Configuration")

# Email Configuration Section
st.sidebar.subheader("📧 Email Settings")
authority_email = st.sidebar.text_input(
    "Authority Email", 
    value="municipal@authority.gov",
    help="Email address of municipal authority to notify"
)

# Show email status
sender_email = os.getenv('SENDER_EMAIL', '')
sender_password = os.getenv('SENDER_PASSWORD', '')
if sender_email and sender_password:
    st.sidebar.success(f"✅ Email configured: {sender_email}")
    if st.sidebar.button("📤 Test Email"):
        success = modules['email_notifier'].send_test_email(authority_email)
        if success:
            st.sidebar.success("Test email sent!")
        else:
            st.sidebar.error("Failed to send test email")
else:
    st.sidebar.warning("⚠️ Email not configured")
    with st.sidebar.expander("Email Setup Instructions"):
        st.markdown("""
        **To enable email notifications:**
        1. Use a Gmail account with 2FA enabled
        2. Generate an App Password for this application
        3. Set BOTH environment variables:
           - `SENDER_EMAIL`: your-email@gmail.com
           - `SENDER_PASSWORD`: your-app-password
        """)
    
    # Show which credentials are missing
    missing_creds = []
    if not sender_email:
        missing_creds.append("SENDER_EMAIL")
    if not sender_password:
        missing_creds.append("SENDER_PASSWORD")
    st.sidebar.info(f"Missing: {', '.join(missing_creds)}")

# AI Configuration Section
st.sidebar.subheader("🤖 AI Settings")
openai_key = os.getenv('OPENAI_API_KEY', '')
if openai_key:
    st.sidebar.success("✅ OpenAI API configured")
else:
    st.sidebar.warning("⚠️ OpenAI API not configured")
    with st.sidebar.expander("OpenAI Setup Instructions"):
        st.markdown("""
        **To enable AI-powered garbage detection:**
        1. Sign up at https://platform.openai.com
        2. Create an API key in your account settings
        3. Set environment variable:
           - `OPENAI_API_KEY`: your-openai-api-key
        """)

# Analysis Configuration
st.sidebar.subheader("🎯 Detection Settings")
location = st.sidebar.text_input(
    "Location/Camera ID", 
    value="Main Street Camera 01",
    help="Location or camera identifier for the footage"
)
confidence_threshold = st.sidebar.slider(
    "Detection Confidence Threshold", 
    min_value=0.1, 
    max_value=1.0, 
    value=0.7,
    help="Minimum confidence score for garbage detection"
)

# Main content tabs
tab1, tab2, tab3 = st.tabs(["📹 Video Analysis", "📊 Dashboard", "📋 Incident Reports"])

with tab1:
    st.header("Video Upload and Analysis")
    
    uploaded_file = st.file_uploader(
        "Upload CCTV footage",
        type=['mp4', 'avi', 'mov', 'mkv'],
        help="Supported formats: MP4, AVI, MOV, MKV"
    )
    
    if uploaded_file is not None:
        # Save uploaded file temporarily
        with tempfile.NamedTemporaryFile(delete=False, suffix='.mp4') as tmp_file:
            tmp_file.write(uploaded_file.read())
            video_path = tmp_file.name
        
        col1, col2 = st.columns([1, 1])
        
        with col1:
            st.subheader("Video Information")
            video_info = modules['video_processor'].get_video_info(video_path)
            st.metric("Duration", f"{video_info['duration']:.2f} seconds")
            st.metric("FPS", f"{video_info['fps']:.2f}")
            st.metric("Resolution", f"{video_info['width']}x{video_info['height']}")
            st.metric("Total Frames", video_info['frame_count'])
        
        with col2:
            st.subheader("Analysis Settings")
            frame_interval = st.number_input(
                "Frame Analysis Interval (seconds)", 
                min_value=1, 
                max_value=30, 
                value=5,
                help="Analyze every N seconds of video"
            )
            
            analyze_button = st.button("🔍 Start Analysis", type="primary")
        
        if analyze_button:
            st.subheader("Analysis Progress")
            progress_bar = st.progress(0)
            status_text = st.empty()
            
            # Extract frames for analysis
            frames = modules['video_processor'].extract_frames(video_path, frame_interval)
            
            detection_results = []
            violations_detected = []
            
            for i, (timestamp, frame) in enumerate(frames):
                progress = (i + 1) / len(frames)
                progress_bar.progress(progress)
                status_text.text(f"Analyzing frame {i+1}/{len(frames)} at {timestamp:.2f}s")
                
                # Analyze frame for garbage
                detection_result = modules['ai_analyzer'].detect_garbage(frame)
                detection_results.append({
                    'timestamp': timestamp,
                    'confidence': detection_result['confidence'],
                    'detected': detection_result['detected'],
                    'description': detection_result['description'],
                    'frame': frame
                })
                
                # Check if violation detected
                if detection_result['detected'] and detection_result['confidence'] >= confidence_threshold:
                    violations_detected.append({
                        'timestamp': timestamp,
                        'confidence': detection_result['confidence'],
                        'description': detection_result['description'],
                        'frame': frame,
                        'location': location
                    })
            
            # Store analysis results
            st.session_state.current_analysis = {
                'video_file': uploaded_file.name,
                'detection_results': detection_results,
                'violations': violations_detected,
                'analysis_time': datetime.now(),
                'location': location
            }
            
            # Clean up temporary file
            os.unlink(video_path)
            
            st.success(f"Analysis complete! Found {len(violations_detected)} violations.")
            
            # Display results
            if violations_detected:
                st.subheader("🚨 Violations Detected")
                
                for idx, violation in enumerate(violations_detected):
                    with st.expander(f"Violation {idx+1} - Confidence: {format_confidence_score(violation['confidence'])}"):
                        col1, col2 = st.columns([1, 1])
                        
                        with col1:
                            st.image(violation['frame'], caption=f"Frame at {violation['timestamp']:.2f}s")
                        
                        with col2:
                            st.write(f"**Timestamp:** {violation['timestamp']:.2f} seconds")
                            st.write(f"**Confidence:** {format_confidence_score(violation['confidence'])}")
                            st.write(f"**Location:** {violation['location']}")
                            st.write(f"**Description:** {violation['description']}")
                
                # Generate and send report
                col1, col2 = st.columns([1, 1])
                
                with col1:
                    if st.button("📧 Send Report to Authorities"):
                        # Save incident to database first
                        incident_id = modules['data_manager'].save_incident_to_database(
                            violations_detected,
                            uploaded_file.name,
                            location,
                            authority_email
                        )
                        
                        if incident_id:
                            report_data = modules['data_manager'].generate_violation_report(
                                violations_detected, 
                                uploaded_file.name, 
                                location
                            )
                            
                            success = modules['email_notifier'].send_violation_report(
                                authority_email, 
                                report_data
                            )
                            
                            if success:
                                # Update incident as notified in database
                                modules['data_manager'].update_incident_notification_status(incident_id, True)
                                st.success("Report sent successfully to authorities and saved to database!")
                                
                                # Also add to session state for immediate display (fallback)
                                incident = {
                                    'id': incident_id,
                                    'timestamp': datetime.now(),
                                    'location': location,
                                    'violations_count': len(violations_detected),
                                    'video_file': uploaded_file.name,
                                    'authority_notified': True,
                                    'authority_email': authority_email
                                }
                                st.session_state.incidents.append(incident)
                            else:
                                st.error("Failed to send report. Incident saved to database but email not sent.")
                        else:
                            st.error("Failed to save incident to database.")
                
                with col2:
                    if st.button("💾 Save to Incident Log"):
                        incident_id = modules['data_manager'].save_incident_to_database(
                            violations_detected,
                            uploaded_file.name,
                            location,
                            authority_email
                        )
                        
                        if incident_id:
                            st.success("Incident saved to database successfully!")
                            
                            # Also add to session state for immediate display
                            incident = {
                                'id': incident_id,
                                'timestamp': datetime.now(),
                                'location': location,
                                'violations_count': len(violations_detected),
                                'video_file': uploaded_file.name,
                                'authority_notified': False,
                                'authority_email': authority_email
                            }
                            st.session_state.incidents.append(incident)
                        else:
                            st.warning("Database not available. Saving to session only.")
                            incident = {
                                'id': len(st.session_state.incidents) + 1,
                                'timestamp': datetime.now(),
                                'location': location,
                                'violations_count': len(violations_detected),
                                'video_file': uploaded_file.name,
                                'authority_notified': False,
                                'authority_email': authority_email
                            }
                            st.session_state.incidents.append(incident)
                            st.success("Incident saved to session log!")
            else:
                st.info("No violations detected in the uploaded footage.")

with tab2:
    st.header("Detection Dashboard")
    
    if st.session_state.current_analysis:
        analysis = st.session_state.current_analysis
        
        # Summary metrics
        col1, col2, col3, col4 = st.columns(4)
        
        with col1:
            st.metric("Total Frames Analyzed", len(analysis['detection_results']))
        
        with col2:
            st.metric("Violations Found", len(analysis['violations']))
        
        with col3:
            avg_confidence = np.mean([r['confidence'] for r in analysis['detection_results'] if r['detected']])
            st.metric("Average Confidence", f"{avg_confidence:.2%}" if not np.isnan(avg_confidence) else "N/A")
        
        with col4:
            st.metric("Analysis Time", analysis['analysis_time'].strftime("%H:%M:%S"))
        
        # Detection timeline
        st.subheader("Detection Timeline")
        
        # Create timeline data
        timeline_data = []
        for result in analysis['detection_results']:
            timeline_data.append({
                'Timestamp (s)': result['timestamp'],
                'Confidence': result['confidence'],
                'Detected': result['detected'],
                'Description': result['description'][:50] + "..." if len(result['description']) > 50 else result['description']
            })
        
        df = pd.DataFrame(timeline_data)
        
        # Filter for detections only
        detected_df = df[df['Detected'] == True]
        
        if not detected_df.empty:
            st.line_chart(detected_df.set_index('Timestamp (s)')['Confidence'])
            
            st.subheader("Detection Details")
            st.dataframe(
                detected_df[['Timestamp (s)', 'Confidence', 'Description']], 
                use_container_width=True
            )
        else:
            st.info("No detections found in current analysis.")
    else:
        st.info("No analysis data available. Please upload and analyze a video first.")

with tab3:
    st.header("Incident Reports")
    
    if st.session_state.incidents:
        st.subheader("Recent Incidents")
        
        # Display incidents in a table
        incidents_data = []
        for incident in reversed(st.session_state.incidents):  # Show most recent first
            incidents_data.append({
                'ID': incident['id'],
                'Timestamp': incident['timestamp'].strftime("%Y-%m-%d %H:%M:%S"),
                'Location': incident['location'],
                'Violations': incident['violations_count'],
                'Video File': incident['video_file'],
                'Authority Notified': "✅" if incident['authority_notified'] else "❌",
                'Authority Email': incident['authority_email']
            })
        
        st.dataframe(pd.DataFrame(incidents_data), use_container_width=True)
        
        # Export functionality
        if st.button("📄 Export Report"):
            csv = pd.DataFrame(incidents_data).to_csv(index=False)
            st.download_button(
                label="Download CSV Report",
                data=csv,
                file_name=f"garbage_detection_report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv",
                mime="text/csv"
            )
    else:
        st.info("No incidents recorded yet. Analyze videos to generate incident reports.")
    
    # Manual incident logging
    with st.expander("➕ Log Manual Incident"):
        st.subheader("Manual Incident Entry")
        
        manual_location = st.text_input("Incident Location")
        manual_description = st.text_area("Incident Description")
        manual_email = st.text_input("Authority Email", value=authority_email)
        
        if st.button("Log Incident"):
            if manual_location and manual_description:
                incident = {
                    'id': len(st.session_state.incidents) + 1,
                    'timestamp': datetime.now(),
                    'location': manual_location,
                    'violations_count': 1,
                    'video_file': 'Manual Entry',
                    'authority_notified': False,
                    'authority_email': manual_email,
                    'description': manual_description
                }
                st.session_state.incidents.append(incident)
                st.success("Manual incident logged successfully!")
                st.rerun()
            else:
                st.error("Please fill in all required fields.")

# Footer
st.markdown("---")
st.markdown("*Garbage Detection System - Powered by AI for Municipal Authorities*")
