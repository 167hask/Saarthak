# Overview

This is an AI-powered garbage detection system that analyzes CCTV footage to identify illegal garbage dumping and littering incidents. The application uses Streamlit for the web interface and integrates with OpenAI's GPT-5 vision model to perform intelligent image analysis. When violations are detected, the system can generate comprehensive reports and automatically notify municipal authorities via email.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
The system uses **Streamlit** as the web framework, providing a simple yet effective interface for uploading videos, configuring settings, and viewing detection results. The main application is contained in `app.py` with a wide layout configuration and session state management for maintaining detection history and current analysis results.

## Modular Backend Design
The backend follows a **modular architecture** with separate components for different responsibilities:

- **VideoProcessor**: Handles video file operations, frame extraction, and metadata retrieval using OpenCV
- **AIAnalyzer**: Interfaces with OpenAI's GPT-5 vision API for intelligent garbage detection in video frames
- **EmailNotifier**: Manages SMTP email notifications to authorities using Gmail's service
- **DataManager**: Handles data processing, report generation, and incident summarization

## AI Detection Strategy
The system employs **frame sampling** rather than real-time processing - it extracts frames from uploaded videos at configurable intervals (default 5 seconds) and analyzes each frame using OpenAI's vision capabilities. This approach balances accuracy with computational efficiency while avoiding the need for local computer vision models.

## Data Flow Design
The application follows a **pipeline architecture**:
1. Video upload and validation
2. Frame extraction at intervals
3. AI-powered analysis of each frame
4. Violation detection and confidence scoring
5. Report generation and email notification
6. Results display and data export

## Configuration Management
The system uses **environment variables** for sensitive configurations like OpenAI API keys and email credentials, with fallback handling when credentials are not configured. This allows the application to run in a degraded mode while clearly indicating what needs to be set up.

# External Dependencies

## AI Services
- **OpenAI GPT-5 Vision API**: Primary AI service for garbage detection in images, configured via `OPENAI_API_KEY` environment variable

## Email Services  
- **Gmail SMTP**: Email delivery service for notifying authorities, requires `SENDER_EMAIL` and `SENDER_PASSWORD` (app password) environment variables

## Core Libraries
- **Streamlit**: Web application framework for the user interface
- **OpenCV (cv2)**: Video processing and frame extraction capabilities  
- **Pandas**: Data manipulation and analysis for detection results
- **NumPy**: Numerical operations for image processing

## Python Standard Libraries
- **smtplib & email.mime**: Email composition and delivery
- **tempfile & os**: File system operations and temporary file handling
- **datetime**: Timestamp management for incidents and reports
- **base64**: Image encoding for API communication