from datetime import datetime
from typing import Any, Union
import streamlit as st

def format_confidence_score(confidence: float) -> str:
    """Format confidence score as percentage with appropriate color coding."""
    percentage = confidence * 100
    if percentage >= 90:
        return f"🔴 {percentage:.1f}%"
    elif percentage >= 70:
        return f"🟡 {percentage:.1f}%"
    else:
        return f"🟢 {percentage:.1f}%"

def format_timestamp(timestamp: Union[float, datetime]) -> str:
    """Format timestamp for display."""
    if isinstance(timestamp, float):
        minutes = int(timestamp // 60)
        seconds = int(timestamp % 60)
        return f"{minutes:02d}:{seconds:02d}"
    elif isinstance(timestamp, datetime):
        return timestamp.strftime("%Y-%m-%d %H:%M:%S")
    else:
        return str(timestamp)

def validate_email(email: str) -> bool:
    """Simple email validation."""
    import re
    pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
    return re.match(pattern, email) is not None

def get_file_size_mb(file_size_bytes: int) -> str:
    """Convert file size to MB string."""
    mb = file_size_bytes / (1024 * 1024)
    return f"{mb:.2f} MB"

def create_download_link(data: str, filename: str, mime_type: str = "text/plain") -> None:
    """Create a download button for data."""
    st.download_button(
        label=f"📥 Download {filename}",
        data=data,
        file_name=filename,
        mime=mime_type
    )

def display_detection_badge(detected: bool, confidence: float) -> str:
    """Create a visual badge for detection status."""
    if detected:
        if confidence >= 0.9:
            return "🚨 HIGH CONFIDENCE VIOLATION"
        elif confidence >= 0.7:
            return "⚠️ MEDIUM CONFIDENCE VIOLATION"
        else:
            return "🔍 LOW CONFIDENCE DETECTION"
    else:
        return "✅ NO VIOLATION DETECTED"

def get_severity_color(severity: str) -> str:
    """Get color code for severity level."""
    colors = {
        'High': '#d32f2f',
        'Medium': '#f57c00',
        'Low': '#388e3c',
        'None': '#757575'
    }
    return colors.get(severity, '#757575')

def truncate_text(text: str, max_length: int = 100) -> str:
    """Truncate text to specified length with ellipsis."""
    if len(text) <= max_length:
        return text
    return text[:max_length-3] + "..."

def format_duration(seconds: float) -> str:
    """Format duration in seconds to human readable format."""
    if seconds < 60:
        return f"{seconds:.1f}s"
    elif seconds < 3600:
        minutes = seconds / 60
        return f"{minutes:.1f}m"
    else:
        hours = seconds / 3600
        return f"{hours:.1f}h"

def validate_video_file(file) -> tuple[bool, str]:
    """Validate uploaded video file."""
    if file is None:
        return False, "No file uploaded"
    
    # Check file size (limit to 100MB)
    if file.size > 100 * 1024 * 1024:
        return False, "File size exceeds 100MB limit"
    
    # Check file extension
    allowed_extensions = ['.mp4', '.avi', '.mov', '.mkv', '.webm']
    file_extension = '.' + file.name.split('.')[-1].lower()
    
    if file_extension not in allowed_extensions:
        return False, f"Unsupported file format. Allowed: {', '.join(allowed_extensions)}"
    
    return True, "Valid file"
